#pragma once

struct Color {
	float r;
	float g;
	float b;
	float a;
};