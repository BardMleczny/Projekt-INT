#pragma once

#include <GL/glew.h>

#include "VertexArray.h"
#include "IndexBuffer.h"
#include "Shader.h"

#include "Camera.h"
#include "Color.h"

#define ASSERT(x) if (!(x)) __debugbreak();
#define GLCall(x) GLClearError();\
    x;\
    ASSERT(GLLogCall(#x, __FILE__, __LINE__))

void GLClearError();
bool GLLogCall(const char* function, const char* file, int line); 

class Rectangle;

static class Renderer {
public:
    void static Clear();
    void static Draw(const VertexArray& va, const IndexBuffer& ib, const Shader& shader);
    void static DrawBatch(const VertexArray& va, const IndexBuffer& ib, const Shader& shader, const unsigned int* indices);
    void static DrawRectangle(const Rectangle& rectangle, const Color& color, Shader& shader, glm::mat4 view = glm::mat4(1.0f));
private:
    
};